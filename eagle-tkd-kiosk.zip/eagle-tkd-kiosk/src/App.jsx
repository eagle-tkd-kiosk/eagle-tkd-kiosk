import React from 'react';
export default function App() {
  return <h1>Master Son’s Eagle Taekwondo Kiosk</h1>;
}
