# Eagle TKD Kiosk (Static)
Build-free kiosk site. Files at repo root.
- index.html (React CDN)
- hero.jpg (background)
- logo.png (logo)
- vercel.json (routes / to /index.html)
